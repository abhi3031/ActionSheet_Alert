
import UIKit

class ViewController: UIViewController {

    var vController = SecondViewController()
    
    @IBOutlet weak var btnEditProfile: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        vController = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
    }

    @IBAction func btneditProfile(_ sender: Any) {
    
        let act = UIAlertController(title: "Edit Profile", message: "kindly modify appropriate data", preferredStyle: .actionSheet)
        let size = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.height)
        vController.preferredContentSize = size.size
        act.addAction(UIAlertAction(title: "Save", style: .default) { (action) in
            
            print("edited!")
            self.btnEditProfile.isHidden = false
        })
        act.addAction(UIAlertAction(title: "Cancel", style: .destructive) { (action) in
            
            print("Canceled!")
            self.btnEditProfile.isHidden = false
        })
        act.setValue(vController, forKey: "ContentViewController")
        self.present(act, animated: true, completion: nil)
        btnEditProfile.isHidden = true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

