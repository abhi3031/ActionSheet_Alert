import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    override func viewDidAppear(_ animated: Bool) {
        
        generateAlert()
    }

    func generateAlert()  {
        
        let alt = UIAlertController(title: "Image Alert", message: "", preferredStyle: .alert)
        alt.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        
        let vController = UIViewController()
        let size = CGRect(x: 0, y: 0, width: 200, height: 120)
        vController.preferredContentSize = size.size
        
        let imgView = UIImageView(frame: CGRect(x: vController.view.frame.origin.x, y: vController.view.frame.origin.y, width: 160, height: 120))
        imgView.image = UIImage(named: "1.png")
        vController.view.addSubview(imgView)
        
        let btnOk = UIButton(type: .roundedRect)
        btnOk.frame = CGRect(x: imgView.frame.origin.x+162, y: imgView.frame.origin.y, width: 25, height: 25)
        btnOk.setTitle("OK", for: .normal)
        vController.view.addSubview(btnOk)
        
        alt.setValue(vController, forKey: "ContentViewController")
        
        self.present(alt, animated: true, completion: nil)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
     }
}

